# ticket_booking

This is a web application for movie ticket booking.
There are 4 microservices :
User Service – This service handles all the activities to user login and registration. 

Two types of user login : Admin and normal user login § Registration of user details  .

Movie Service – This service handles all the independent activities related to movies. 
The following functionalities are handled in this service. 
Add/Edit/Delete a Movie related informations. View and search movies  

Theatre Service – This service handles all the activities to theatre. 
Admin can add/update/delete new theatre/seating capacity/location.
View the list of theatres  

Booking Service – This service handles all the booking related things like booking a ticket etc. 
User can book the ticket according to the movie name, theatrename, date and time. 
User can also cancel the tickets.
User can aslo search his booking details.
User can search all the theatre and show details by giving the movie name.
Report generation of total bookings according to a period till what we need to search for the booking details, and also can search according to the movienames.
 
Zuul - Zuul is a gateway through which we can directly call our api without going to specific ports.
Zuul is registered at port: 9999

Steps to start project:
1. Start the Eureka service at port 8761. 
2. Start the Zuul proxy gateway.
3. Start all the micro-services.
4 Check at port 8761 whether all the services are registering in the eureka server.
5. For using any api go to postman and type http://localhost:9999/service_name/api_name
	Eg.
	http://localhost:9999/user/login
6. Check all the api according to the swagger api documentation of every micro-service.

