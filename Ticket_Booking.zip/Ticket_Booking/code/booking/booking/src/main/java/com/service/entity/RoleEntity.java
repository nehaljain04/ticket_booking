package com.service.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="role")
public class RoleEntity {

	@Id
	private String rolename;
	public String getRole() {
		return this.rolename;
	}
	public void setRole(String role) {
		this.rolename=role;
	}
}
