package com.service.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.service.entity.RoleEntity;
import com.service.entity.UserEntity;
import com.service.model.User;

@Repository(value = "userManagementDAO")
public class UserManagementDAOImpl implements UserManagementDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public User getUserByName(String username) {
		User newUser=null;
		
		UserEntity userEntity=entityManager.find(UserEntity.class,username);
		
		if(userEntity !=null) {
			newUser=new User();
			newUser.setUsername(userEntity.getUsername());
			newUser.setPassword(userEntity.getPassword());
			newUser.setEmail(userEntity.getEmail());
			newUser.setMobile(userEntity.getMobile());
			newUser.setRole(userEntity.getRole().getRole());
			
		}
		return newUser;
	}

	@Override
	public String addUser(User user){
		String username;
		UserEntity user1=new UserEntity();
		RoleEntity roleEntity=entityManager.find(RoleEntity.class, "user");
		username=user.getUsername();
		user1.setUsername(user.getUsername());
		user1.setPassword(user.getPassword());
		user1.setEmail(user.getEmail());
		user1.setMobile(user.getMobile());
		user1.setRole(roleEntity);
		entityManager.persist(user1);
		return username;
	}

}
