use test;
create table role(role varchar(5));
create table user(username varchar(30) primary key,passwrd varchar(20),mobile decimal(10),email varchar(30),role varchar(5));
insert into user values("admin","admin");
insert into user values()

