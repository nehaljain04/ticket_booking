package com.service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.service.dao.MovieManagementDAO;
import com.service.model.Movie;

@Service(value = "movieManagementService")
@Transactional
public class MovieManagementServiceImpl implements MovieManagementService{
	
	@Autowired
	private MovieManagementDAO movieManagementDAO;

	@Override
	public Movie getMovieDetails(String moviename) throws Exception {
		Movie movie=null;;
		movie=movieManagementDAO.getMovieDetails(moviename);
		if (movie == null) {
			throw new Exception("Service.MOVIE_NOT_FOUND");
		}
		return movie;
	}

	@Override
	public String addMovie(Movie movie) throws Exception {
		String username;
		username=movieManagementDAO.addMovie(movie);
		if(username==null) {
			throw new Exception("Service.MOVIE_ALREADY_EXISTS");
		}
		return username;
	}

	@Override
	public void updateMovie(String moviename,Integer ratings)throws Exception{
		Movie movie = movieManagementDAO.getMovieDetails(moviename);
		if (movie == null) {
			throw new Exception("Service.MOVIE_NOT_FOUND");
		}		
		movieManagementDAO.updateUser(moviename, ratings);
		
	}

	@Override
	public void deleteUser(String moviename) throws Exception {
		Movie movie = movieManagementDAO.getMovieDetails(moviename);
		if (movie == null) {
			throw new Exception("Service.MOVIE_NOT_FOUND");
		}		
		movieManagementDAO.deleteMovie(moviename);
	}

	@Override
	public List<Movie> getAllMovie() throws Exception {
		List<Movie> movieList=movieManagementDAO.getAllMovie();
		if(movieList==null) {
			throw new Exception("Service.MOVIE_DETAILS_NOT_FOUND");
		}
		return movieList;
	}

}
