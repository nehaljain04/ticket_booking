package com.service.service;

import java.util.List;

import com.service.model.Theatre;

public interface TheatreManagementService {

	Theatre getTheatreDetails(String theatrename)throws Exception;

	String addTheatre(Theatre theatre)throws Exception;

	void updateTheatre(String theatrename, Integer seatcapacity)throws Exception;

	void deleteTheatre(String theatrename)throws Exception;

	List<Theatre> getAllTheatre()throws Exception;

}
