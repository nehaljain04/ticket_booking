package com.service.dao;

import com.service.model.User;

public interface UserManagementDAO {

	public User getUserByName(String username);

	public String addUser(User user);

}
