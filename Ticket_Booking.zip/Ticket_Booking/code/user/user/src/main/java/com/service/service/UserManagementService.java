package com.service.service;

import com.service.model.User;

public interface UserManagementService {

	public User validateUser(User user) throws Exception;

	public String registerUser(User user) throws Exception;

}
