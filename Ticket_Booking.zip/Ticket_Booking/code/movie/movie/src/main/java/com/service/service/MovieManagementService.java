package com.service.service;

import java.util.List;

import com.service.model.Movie;

public interface MovieManagementService {

	Movie getMovieDetails(String moviename)throws Exception;
	String addMovie(Movie movie)throws Exception;
	void updateMovie(String moviename,Integer ratings)throws Exception;
	public void deleteUser(String moviename) throws Exception;
	List<Movie> getAllMovie() throws Exception;

}
