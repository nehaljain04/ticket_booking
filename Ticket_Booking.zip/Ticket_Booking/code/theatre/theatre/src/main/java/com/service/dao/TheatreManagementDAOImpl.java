package com.service.dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.service.entity.TheatreEntity;
import com.service.model.Theatre;

@Repository(value = "threatreManagementDAO")
public class TheatreManagementDAOImpl implements TheatreManagementDAO{
	
	
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public Theatre getTheatreDetails(String theatrename) {
		Theatre theatre=null;
		TheatreEntity theatreEntity;
		theatreEntity=entityManager.find(TheatreEntity.class, theatrename);
		if(theatreEntity!=null) {
			theatre=new Theatre();
			theatre.setTheatrename(theatreEntity.getTheatrename());
			theatre.setLocation(theatreEntity.getLocation());
			theatre.setSeatcapacity(theatreEntity.getSeatcapacity());
		}
		return theatre;
	}
	@Override
	public String addTheatre(Theatre theatre) {
		TheatreEntity theatreEntity=new TheatreEntity();
		theatreEntity.setTheatrename(theatre.getTheatrename());
		theatreEntity.setLocation(theatre.getLocation());
		theatreEntity.setSeatcapacity(theatre.getSeatcapacity());
		entityManager.persist(theatreEntity);
		return theatreEntity.getTheatrename();
	}
	@Override
	public void updateTheatre(String theatrename, Integer seatcapacity) {
		TheatreEntity theatreEntity=entityManager.find(TheatreEntity.class,theatrename);
		theatreEntity.setSeatcapacity(seatcapacity);	
	}
	
	@Override
	public void deleteTheatre(String theatrename) {
		TheatreEntity theatreEntity=entityManager.find(TheatreEntity.class,theatrename);
		entityManager.remove(theatreEntity);
	}
	
	@Override
	public List<Theatre> getAllTheatre() {
		List<Theatre> theatreList=null;
		String queryString ="select d from TheatreEntity d";
		Query query=entityManager.createQuery(queryString);
		List<TheatreEntity> result = query.getResultList();
		theatreList=new ArrayList<Theatre>();
		for(TheatreEntity theatreEntity:result) {
			Theatre theatre=new Theatre();
			theatre.setTheatrename(theatreEntity.getTheatrename());
			theatre.setLocation(theatreEntity.getLocation());
			theatre.setSeatcapacity(theatreEntity.getSeatcapacity());
			theatreList.add(theatre);
		}
		return theatreList;
	}

}
