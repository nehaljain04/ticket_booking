package com.service.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.service.dao.BookingManagementDAO;
import com.service.model.Booking;
import com.service.model.Seat;

@Service(value = "bookingManagementService")
@Transactional
public class BookingManagementServiceImpl implements BookingManagementService {

	@Autowired
	private BookingManagementDAO bookingManagementDAO;

	@Override
	public Seat seatDetails(Seat seat) throws Exception {
		Seat seatNew = bookingManagementDAO.seatDetails(seat);
		if (seatNew == null) {
			throw new Exception("Service.DETAILS_NOT_FOUND");
		}
		return seatNew;
	}

	@Override
	public Integer bookTicket(Seat seat) throws Exception {
		if (seat.getUsername() == null) {
			throw new Exception("Service.USER_DETAILS_NOT_FOUND");
		}

		Seat seatNew = bookingManagementDAO.seatDetails(seat);
		if (seatNew == null) {
			throw new Exception("Service.DETAILS_NOT_FOUND");
		}
		if (seatNew.getRemainingseats() < seatNew.getSeatrequired()) {
			throw new Exception("Service.NO_SEATS_AVAILABLE");
		}
		Integer bookingid = bookingManagementDAO.bookTicket(seatNew);

		if (bookingid == null) {
			throw new Exception("Service.BOOKING_CANNOT_BE_COMPLETED");
		}
		bookingManagementDAO.setSeat(seatNew);
		return bookingid;
	}

	@Override
	public Booking bookingDetails(String username) throws Exception {
		Booking booking = bookingManagementDAO.bookingDetails(username);
		if (booking == null) {
			throw new Exception("Service.DETAILS_NOT_FOUND");
		}
		return booking;
	}

	@Override
	public void deleteBooking(String username) throws Exception {
		Booking booking = bookingManagementDAO.bookingDetails(username);
		if (booking == null) {
			throw new Exception("Service.DETAILS_NOT_FOUND");
		}
		bookingManagementDAO.deleteBooking(booking);
	}

	@Override
	public List<Seat> getDetails(String moviename) throws Exception {
		List<Seat> seatList = bookingManagementDAO.getDetails(moviename);
		if (seatList == null) {
			throw new Exception("Service.DETAILS_NOT_FOUND");
		}
		return seatList;
	}

	@Override
	public List<Booking> report(Booking booking) throws Exception {
		List<Booking> bookingList = bookingManagementDAO.report(booking);
		if (bookingList == null) {
			throw new Exception("Service.DETAILS_NOT_FOUND");
		}
		return bookingList;
	}

	@Override
	public Integer addDetails(Seat seat) throws Exception {
		Integer seatid = bookingManagementDAO.addDetails(seat);
		if (seatid == null) {
			throw new Exception("Service.DETAILS_NOT_FOUND");
		}
		return seatid;
	}

	@Override
	public void delete(Integer bookingid) throws Exception {

		String username = bookingManagementDAO.delete(bookingid);
		deleteBooking(username);
	}

}
