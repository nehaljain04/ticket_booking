package com.service.model;

public class User {

	private String username;
	private String passwrd;
	private Long mobile;
	private String email;
	private String rolename;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return passwrd;
	}
	public void setPassword(String password) {
		this.passwrd = password;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return rolename;
	}
	public void setRole(String role) {
		this.rolename = role;
	}
}
