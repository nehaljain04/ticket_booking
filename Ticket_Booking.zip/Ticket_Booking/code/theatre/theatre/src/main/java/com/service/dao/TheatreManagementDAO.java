package com.service.dao;

import java.util.List;

import com.service.model.Theatre;

public interface TheatreManagementDAO {

	Theatre getTheatreDetails(String theatrename);

	String addTheatre(Theatre theatre);

	void updateTheatre(String theatrename, Integer seatcapacity);

	void deleteTheatre(String theatrename);

	List<Theatre> getAllTheatre();

}
