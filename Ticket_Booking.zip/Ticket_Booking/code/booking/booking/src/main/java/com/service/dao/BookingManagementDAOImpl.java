package com.service.dao;

import java.text.DateFormat;
//import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.service.entity.BookingEntity;
import com.service.entity.MovieEntity;
import com.service.entity.SeatEntity;
import com.service.entity.TheatreEntity;
import com.service.entity.UserEntity;
import com.service.model.Booking;
//import com.service.model.Booking;
import com.service.model.Seat;

@Repository(value = "bookingManagementDAO")
public class BookingManagementDAOImpl implements BookingManagementDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Seat seatDetails(Seat seat) throws ParseException {
	
		Seat seatNew = null;
		String tname = seat.getTheatrename();
		String username = seat.getUsername();
		String mname = seat.getMoviename();
		String tme = seat.getTime();
		String date = seat.getDate();
		
		String queryString = "select s from SeatEntity s";
		Query query = entityManager.createQuery(queryString);
		List<SeatEntity> result = query.getResultList();
		for (SeatEntity seatEntity : result) {
			if (seatEntity.getMoviename().getMoviename().equals(mname)
					&& seatEntity.getTheatrename().getTheatrename().equals(tname)
					&& seatEntity.getDate().toString().substring(0, 10).equals(date)
					&& seatEntity.getTime().equals(tme)) {
				
				seatNew = new Seat();
				seatNew.setSeatid(seatEntity.getSeatid());
				seatNew.setMoviename(seat.getMoviename());
				seatNew.setTheatrename(seat.getTheatrename());
				seatNew.setDate(seatEntity.getDate());
				seatNew.setTime(seat.getTime());
				seatNew.setRate(seatEntity.getRate());
				seatNew.setRemainingseats(seatEntity.getRemainingseats());
				seatEntity.setSeatrequired(seat.getSeatrequired());
				seatNew.setSeatrequired(seat.getSeatrequired());
				seatEntity.setUsername(username);
				seatNew.setUsername(username);
				System.out.println("found one username: "+username);
				return seatNew;
			}
		}
		return seatNew;
	}

	@Override
	public Integer bookTicket(Seat seatNew) {

		UserEntity userEntity = entityManager.find(UserEntity.class, seatNew.getUsername());
		BookingEntity bookingEntity = new BookingEntity();
//		bookingEntity.setBookingid(1);
		bookingEntity.setMname(seatNew.getMoviename());
		bookingEntity.setTname(seatNew.getTheatrename());
		bookingEntity.setDate(seatNew.getDate());
		bookingEntity.setTime(seatNew.getTime());
		bookingEntity.setSeatbooked(seatNew.getSeatrequired());
		bookingEntity.setAmount((seatNew.getRate() * seatNew.getSeatrequired()));
	//  userEntity.setUsername(seatNew.getUsername());
		bookingEntity.setUsername(userEntity);
		entityManager.persist(bookingEntity);
		System.out.println("booking done");
		return bookingEntity.getBookingid();
	}

	@Override
	public void setSeat(Seat seatNew) {
		
		SeatEntity seatEntity = entityManager.find(SeatEntity.class, seatNew.getSeatid());
		Integer i = seatEntity.getRemainingseats() - seatEntity.getSeatrequired();
		seatEntity.setRemainingseats(i);
	}

	@Override
	public Booking bookingDetails(String username) {
		Booking booking = new Booking();
		String queryString = "select b from BookingEntity b";
		Query query = entityManager.createQuery(queryString);
		List<BookingEntity> result = query.getResultList();

		for (BookingEntity bookEntity : result) {
			if (bookEntity.getUsername().getUsername().equals(username)) {
				booking.setBookingid(bookEntity.getBookingid());
				booking.setUsername(username);
				booking.setTname(bookEntity.getTname());
				booking.setMname(bookEntity.getMname());
				booking.setAmount(bookEntity.getAmount());
				booking.setDate(bookEntity.getDate());
				booking.setTime(bookEntity.getTime());
				booking.setSeatbooked(bookEntity.getSeatbooked());
				return booking;
			}
		}
		return null;
	}

	@Override
	public void deleteBooking(Booking booking) {
		
		Integer bookingid=booking.getBookingid();
		BookingEntity bookingEntity=entityManager.find(BookingEntity.class,bookingid);
		Integer seatid=null;
		
		String queryString = "select s from SeatEntity s";
		Query query = entityManager.createQuery(queryString);
		List<SeatEntity> result = query.getResultList();
		for (SeatEntity seatEntity : result) {
			if(seatEntity.getMoviename().getMoviename().equals(booking.getMname()) && 
					seatEntity.getTheatrename().getTheatrename().equals(booking.getTname()) && 
					seatEntity.getDate().equals(booking.getDate()) && seatEntity.getTime().equals(booking.getTime())){	
				seatid=seatEntity.getSeatid();
			} 
		}
		
		SeatEntity seatEntity=entityManager.find(SeatEntity.class, seatid);
		seatEntity.setRemainingseats(seatEntity.getRemainingseats()+booking.getSeatbooked());
		entityManager.remove(bookingEntity);
		
		
	}

	@Override
	public List<Seat> getDetails(String moviename) {
		List<Seat> seatList=new ArrayList<Seat>();
		String queryString = "select s from SeatEntity s";
		Query query = entityManager.createQuery(queryString);
		List<SeatEntity> result = query.getResultList();
		for(SeatEntity seatEntity:result) {
			if(seatEntity.getMoviename().getMoviename().equals(moviename)) {
				Seat seat=new Seat();
				seat.setSeatid(seatEntity.getSeatid());
				seat.setMoviename(moviename);
				seat.setTheatrename(seatEntity.getTheatrename().getTheatrename());
				seat.setDate(seatEntity.getDate());
				seat.setTime(seatEntity.getTime());
				seat.setSeatrequired(seatEntity.getSeatrequired());
				seat.setRemainingseats(seatEntity.getRemainingseats());
				seat.setUsername(seatEntity.getUsername());
				seat.setRate(seatEntity.getRate());
				seatList.add(seat);
			}
		}
		return seatList;
	}

	@Override
	public List<Booking> report(Booking booking) throws ParseException {
		List<Booking> bookingList=new ArrayList<Booking>();
		String dd=booking.getDate();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date1 = (Date)format.parse(dd);
		String queryString = "select b from BookingEntity b";
		Query query = entityManager.createQuery(queryString);
		List<BookingEntity> result = query.getResultList();
		for(BookingEntity bookingEntity:result) {
			Booking book=new Booking();
			Date date2=(Date)format.parse(bookingEntity.getDate());
			if(booking.getMname()!=null) {
				if(date1.compareTo(date2)>=0) {
					if(booking.getMname().equals(bookingEntity.getMname())) {
						book.setBookingid(bookingEntity.getBookingid());
						book.setAmount(bookingEntity.getAmount());
						book.setDate(bookingEntity.getDate());
						book.setMname(bookingEntity.getMname());
						book.setTname(bookingEntity.getTname());
						book.setTime(bookingEntity.getTime());
						book.setUsername(bookingEntity.getUsername().getUsername());
						book.setSeatbooked(bookingEntity.getSeatbooked());
						bookingList.add(book);
					}
				}
			}
			else {
				if(date1.compareTo(date2)>=0) {
					book.setBookingid(bookingEntity.getBookingid());
					book.setAmount(bookingEntity.getAmount());
					book.setDate(bookingEntity.getDate());
					book.setMname(bookingEntity.getMname());
					book.setTname(bookingEntity.getTname());
					book.setTime(bookingEntity.getTime());
					book.setUsername(bookingEntity.getUsername().getUsername());
					book.setSeatbooked(bookingEntity.getSeatbooked());
					bookingList.add(book);
				}
			}	
		}	
		return bookingList;
	}

	@Override
	public Integer addDetails(Seat seat) {
		
		SeatEntity seatEntity=new SeatEntity();
		MovieEntity movieEntity=entityManager.find(MovieEntity.class,seat.getMoviename());
		TheatreEntity theatreEntity=entityManager.find(TheatreEntity.class,seat.getTheatrename());
		
		//seatEntity.setSeatid(seat.getSeatid());
		seatEntity.setMoviename(movieEntity);
		seatEntity.setTheatrename(theatreEntity);
		seatEntity.setDate(seat.getDate());
		seatEntity.setTime(seat.getTime());
		seatEntity.setRemainingseats(seat.getRemainingseats());
		seatEntity.setRate(seat.getRate());
		entityManager.persist(seatEntity);
		return seatEntity.getSeatid();
	}

	@Override
	public String delete(Integer bookingid) {
		BookingEntity bookEntity=entityManager.find(BookingEntity.class, bookingid);
		
		UserEntity userEntity=entityManager.find(UserEntity.class, bookEntity.getUsername());
//		Integer id=bookEntity.getBookingid();
//		entityManager.remove(bookEntity);
		return userEntity.getUsername();
	}
}

/*Conversion of string to date format*/
//System.out.println("seat name-------##"+mname);
//String dd=seat.getDate().toString();
//DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
//Date date = (Date)formatter.parse(dd);
//System.out.println(date);        
//
//Calendar cal = Calendar.getInstance();
//cal.setTime(date);
//String formatedDate = cal.get(Calendar.YEAR) + "-0" + (cal.get(Calendar.MONTH) + 1) + "-" +cal.get(Calendar.DATE);
//System.out.println("formatedDate : " + formatedDate);  

//String d=dd.toString();
