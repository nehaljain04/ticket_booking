package com.service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.service.dao.TheatreManagementDAO;
import com.service.model.Theatre;

@Service(value = "theatreManagementService")
@Transactional
public class TheatreManagementServiceImpl implements TheatreManagementService {
	
	@Autowired
	private TheatreManagementDAO theatreManagementDAO;

	@Override
	public Theatre getTheatreDetails(String theatrename) throws Exception {
		Theatre theatre=null;
		theatre=theatreManagementDAO.getTheatreDetails(theatrename);
		if(theatre==null) {
			throw new Exception("Service.THEATRE_NOT_FOUND");
		}
		return theatre;
	}

	@Override
	public String addTheatre(Theatre theatre) throws Exception {
		String theatrename;
		theatrename=theatreManagementDAO.addTheatre(theatre);
		return theatrename;
	}

	@Override
	public void updateTheatre(String theatrename, Integer seatcapacity) throws Exception {
		Theatre theatre;
		theatre=theatreManagementDAO.getTheatreDetails(theatrename);
		if(theatre==null) {
			throw new Exception("Service.THEATRE_NOT_FOUND");
		}
		theatreManagementDAO.updateTheatre(theatrename,seatcapacity);
	}

	@Override
	public void deleteTheatre(String theatrename) throws Exception {
		Theatre theatre;
		theatre=theatreManagementDAO.getTheatreDetails(theatrename);
		if(theatre==null) {
			throw new Exception("Service.THEATRE_NOT_FOUND");
		}
		theatreManagementDAO.deleteTheatre(theatrename);
	}

	@Override
	public List<Theatre> getAllTheatre() throws Exception {
		List<Theatre> theatreList=theatreManagementDAO.getAllTheatre();
		if(theatreList==null) {
			throw new Exception("Service.THEATRE_DETAILS_NOT_FOUND");
		}
		return theatreList;
	}
	


}
