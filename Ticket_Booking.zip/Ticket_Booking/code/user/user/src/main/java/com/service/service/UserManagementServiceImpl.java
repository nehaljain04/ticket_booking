package com.service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.service.dao.UserManagementDAO;
import com.service.model.User;

@Service(value = "UserManagementService")
@Transactional
public class UserManagementServiceImpl implements UserManagementService {

	@Autowired
	private UserManagementDAO userManagementDAO;

	@Override
	public User validateUser(User user) throws Exception {
		User newuser = null;
		User user1 = userManagementDAO.getUserByName(user.getUsername());
		if (user1.getPassword().equals(user.getPassword())) {
			System.out.println("service class if");
			newuser = user1;
		}
		else {
			throw new Exception("Service.PASSWORD_DOES_NOT_MATCH");
		}
		return newuser;
	}

	@Override
	public String registerUser(User user) throws Exception {
		String username = null;
		username = userManagementDAO.addUser(user);
		if(username==null) {
			throw new Exception("USER.EXIST");
		}
		return username;
	}

}
