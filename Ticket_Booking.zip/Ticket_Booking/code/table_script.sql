create database ticket;
use ticket;
 
create table role(rolename varchar(10) primary key);
insert into role values("admin");
insert into role values("user");
select * from role;

create table user(username varchar(30) primary key,passwrd varchar(20) not null,
mobile decimal(10),email varchar(30) not null,rolename varchar(10), 
foreign key(rolename) references role(rolename));

insert into user values("admin","admin",9876543210,"admin@gmail.com","admin");
select * from user;

//demo data
insert into user values("nehal","nehal",9876543210,"nehal@gmail.com","user");

//movie
create table movie(moviename varchar(30) primary key,ratings integer,genre varchar(20));

//theatre
create table theatre(theatrename varchar(30) primary key,location varchar(30),seatcapacity integer);

//seat
create table seat(seatid integer primary key,theatrename varchar(30),moviename varchar(30),date varchar(20),time varchar(20),remainingseats integer,rate integer, seatrequired integer, username varchar(30));
alter table seat add foreign key(theatrename) references theatre(theatrename);
alter table seat add foreign key(moviename) references movie(moviename);

//booking
create table booking(bookingid integer primary key,mname varchar(30),tname varchar(30),username varchar(30) unique,date varchar(20),time varchar(20),amount integer, seatbooked integer);
alter table booking add foreign key(username) references user(username);
