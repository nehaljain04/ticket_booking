package com.service.Service;
import java.util.List;

import com.service.model.Booking;
import com.service.model.Seat;

public interface BookingManagementService {

	Seat seatDetails(Seat seat)throws Exception;
	Integer bookTicket(Seat seat)throws Exception;
	Booking bookingDetails(String username)throws Exception;
	void deleteBooking(String username)throws Exception;
	List<Seat> getDetails(String moviename)throws Exception;
	List<Booking> report(Booking booking)throws Exception;
	Integer addDetails(Seat seat)throws Exception;
	void delete(Integer bookingid)throws Exception;
}
