package com.service.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import com.service.model.Movie;
import com.service.model.ResponseMsg;
import com.service.service.MovieManagementService;

@CrossOrigin
@RestController
@ComponentScan("com.service.*")
@RequestMapping(value="")
public class MovieApi {
	
	@Autowired
	private MovieManagementService movieManagementService;
	
	@GetMapping(value="/all")
	public ResponseEntity<List<Movie>> getAllMovie()throws Exception{
		List<Movie> movieList=movieManagementService.getAllMovie();
		ResponseEntity<List<Movie>> response = new ResponseEntity<List<Movie>>(movieList, HttpStatus.OK);
		return response;
		
	}
	
	@GetMapping(value = "get/{moviename}")
	public ResponseEntity<Movie> getMovieDetails(@PathVariable String moviename)throws Exception{
		try {
			Movie movie=null;
			movie=movieManagementService.getMovieDetails(moviename);
			ResponseEntity<Movie> response=new ResponseEntity<Movie>(movie, HttpStatus.OK);
			return response;
		}
		catch(Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(),e);
		}
		
	}
 	@PostMapping(value = "/add")
	public ResponseEntity<ResponseMsg> addMovie(@RequestBody Movie movie)throws Exception{
		try {
			movieManagementService.addMovie(movie);
			String successMessage = "Movie added successfully";
			ResponseMsg responseMsg = new ResponseMsg();
			responseMsg.setResponseMsg(successMessage);
			ResponseEntity<ResponseMsg> response = new ResponseEntity<ResponseMsg>(responseMsg, HttpStatus.CREATED);
			return response;
		}
		catch(Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(),e);
		}
	}
	 	
 	@PutMapping(value="/update")
 	public ResponseEntity<ResponseMsg> updateMovie(@RequestBody Movie movie)throws Exception{
 		try {
 			movieManagementService.updateMovie(movie.getMoviename(),movie.getRatings());
			String successMessage = "Movie ratings updated successfully";
			ResponseMsg responseMsg = new ResponseMsg();
			responseMsg.setResponseMsg(successMessage);
			ResponseEntity<ResponseMsg> response = new ResponseEntity<ResponseMsg>(responseMsg, HttpStatus.CREATED);
			return response;
 		}
 		catch(Exception e) {
 			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(),e);
 		}	
 	}
 	 @DeleteMapping(value = "/delete/{moviename}")
 	public ResponseEntity<ResponseMsg> deleteCustomer(@PathVariable String moviename) throws Exception  {
 		movieManagementService.deleteUser(moviename);
 		String successMessage = "Movie deleted successfully";
 		ResponseMsg responseMsg = new ResponseMsg();
 		responseMsg.setResponseMsg(successMessage);
 		ResponseEntity<ResponseMsg> response = new ResponseEntity<ResponseMsg>(responseMsg, HttpStatus.OK);
 		return response;
     }
}
