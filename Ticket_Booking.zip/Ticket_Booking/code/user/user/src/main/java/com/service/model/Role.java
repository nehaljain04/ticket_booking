package com.service.model;

public class Role {
private String rolename;

public String getRole() {
	return rolename;
}

public void setRole(String role) {
	this.rolename = role;
}
}
