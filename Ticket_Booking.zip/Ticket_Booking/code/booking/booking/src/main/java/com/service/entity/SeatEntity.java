package com.service.entity;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="seat")
public class SeatEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer seatid;
	private Integer seatrequired;
	private String date;
	private String username;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Integer getSeatrequired() {
		return seatrequired;
	}
	public void setSeatrequired(Integer seatrequired) {
		this.seatrequired = seatrequired;
	}
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="theatrename")
	private TheatreEntity theatrename;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="moviename")
	private MovieEntity moviename;
	
	private Integer remainingseats;
	private Integer rate;
	
	private String time;
	public Integer getSeatid() {
		return seatid;
	}
	public void setSeatid(Integer seatid) {
		this.seatid = seatid;
	}
	public TheatreEntity getTheatrename() {
		return theatrename;
	}
	public void setTheatrename(TheatreEntity theatrename) {
		this.theatrename = theatrename;
	}
	public MovieEntity getMoviename() {
		return moviename;
	}
	public void setMoviename(MovieEntity moviename) {
		this.moviename = moviename;
	}
	public Integer getRemainingseats() {
		return remainingseats;
	}
	public void setRemainingseats(Integer remainingseats) {
		this.remainingseats = remainingseats;
	}
	public Integer getRate() {
		return rate;
	}
	public void setRate(Integer rate) {
		this.rate = rate;
	}
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
}
