package com.service.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="theatre")
public class TheatreEntity {

	@Id
	private String theatrename;
	private String location;
	private Integer seatcapacity;
	public String getTheatrename() {
		return theatrename;
	}
	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Integer getSeatcapacity() {
		return seatcapacity;
	}
	public void setSeatcapacity(Integer seatcapacity) {
		this.seatcapacity = seatcapacity;
	}
}
