package com.service.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import com.service.Service.BookingManagementService;
import com.service.model.Booking;
//import com.service.model.Booking;
import com.service.model.ResponseMsg;
import com.service.model.Seat;

@CrossOrigin
@RestController
@ComponentScan("com.service.*")
@RequestMapping(value = "")
public class BookingApi {

	@Autowired
	private BookingManagementService bookingManagementService;

	@GetMapping(value = "get/{moviename}")
	public ResponseEntity<List<Seat>> getDetails(@PathVariable String moviename) throws Exception {
		try {
			List<Seat> seatList = bookingManagementService.getDetails(moviename);
			ResponseEntity<List<Seat>> response = new ResponseEntity<List<Seat>>(seatList, HttpStatus.OK);
			return response;

		} catch (Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		}
	}

	@PostMapping(value = "/book")
	public ResponseEntity<ResponseMsg> bookTicket(@RequestBody Seat seat) throws Exception {
		try {
			bookingManagementService.bookTicket(seat);

			String successMessage = "Ticket booked successfully";
			ResponseMsg responseMsg = new ResponseMsg();
			responseMsg.setResponseMessage(successMessage);
			ResponseEntity<ResponseMsg> response = new ResponseEntity<ResponseMsg>(responseMsg, HttpStatus.CREATED);
			return response;
		} catch (Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		}
	}

	@GetMapping(value = "/user/{username}")
	public ResponseEntity<Booking> bookingDetails(@PathVariable String username) throws Exception {
		try {
			Booking booking = bookingManagementService.bookingDetails(username);
			ResponseEntity<Booking> response = new ResponseEntity<Booking>(booking, HttpStatus.OK);
			return response;
		} catch (Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		}
	}

	@DeleteMapping(value = "/delete/{username}")
	public ResponseEntity<ResponseMsg> deleteBooking(@PathVariable String username) throws Exception {
		try {
			bookingManagementService.deleteBooking(username);
			String successMessage = "Movie deleted successfully";
			ResponseMsg responseMsg = new ResponseMsg();
			responseMsg.setResponseMessage(successMessage);
			ResponseEntity<ResponseMsg> response = new ResponseEntity<ResponseMsg>(responseMsg, HttpStatus.OK);
			return response;
		} catch (Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		}
	}

	@GetMapping(value = "/report")
	public ResponseEntity<List<Booking>> report(@RequestBody Booking booking) throws Exception {
		try {
			List<Booking> booking1 = bookingManagementService.report(booking);
			ResponseEntity<List<Booking>> response = new ResponseEntity<List<Booking>>(booking1, HttpStatus.OK);
			return response;
		} catch (Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		}
	}

	@PostMapping(value = "/add")
	public ResponseEntity<ResponseMsg> add(@RequestBody Seat seat) throws Exception {
		System.out.println("helllloooooooooooooooooo");
		try {
			System.out.println("hello api class");
			Integer seatid = bookingManagementService.addDetails(seat);
			System.out.println(seatid);
			String successMessage = "seat added successfully";
			ResponseMsg responseMsg = new ResponseMsg();
			responseMsg.setResponseMessage(successMessage);
			ResponseEntity<ResponseMsg> response = new ResponseEntity<ResponseMsg>(responseMsg, HttpStatus.CREATED);
			return response;
		} catch (Exception e) {
			System.out.println("error");
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		}
	}
}

/* seat Deatils */
//@PostMapping(value="/seatDetails")
//public ResponseEntity<Seat> seatDetails(@RequestBody Seat seat)throws Exception{
//	try{
//		Seat seatNew=bookingManagementService.seatDetails(seat);
//		if(seatNew!=null) {
//			ResponseEntity<Seat> response=new ResponseEntity<Seat>(seatNew, HttpStatus.OK);
//			return response;
//		}
//	}
//		catch(Exception e) {
//			System.out.println(e);
//			throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(),e);
//		}
//	return null;
//}

/* Deleting using booking id */

//@DeleteMapping(value="/delete/{bookingid}")
//public ResponseEntity<ResponseMsg> delete(@PathVariable Integer bookingid)throws Exception{
//	System.out.println("delete");
//	try {
//		bookingManagementService.delete(bookingid);
//		String successMessage = "Movie deleted successfully";
// 		ResponseMsg responseMsg = new ResponseMsg();
// 		responseMsg.setResponseMessage(successMessage);
// 		ResponseEntity<ResponseMsg> response = new ResponseEntity<ResponseMsg>(responseMsg, HttpStatus.OK);
// 		return response;
//	}
//	catch(Exception e) {
//		System.out.println(e);
//		throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(),e);
//	}
//}
