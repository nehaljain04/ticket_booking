package com.service.dao;

import java.util.List;

import com.service.model.Movie;

public interface MovieManagementDAO {

	Movie getMovieDetails(String moviename);
	String addMovie(Movie movie);
	Void updateUser(String moviename,Integer ratings);
	void deleteMovie(String moviename);
	List<Movie> getAllMovie();

}
