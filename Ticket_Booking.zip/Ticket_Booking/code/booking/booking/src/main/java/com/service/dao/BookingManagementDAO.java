package com.service.dao;

import java.text.ParseException;
import java.util.List;

import com.service.model.Booking;
import com.service.model.Seat;


public interface BookingManagementDAO {

	Seat seatDetails(Seat seat) throws ParseException;
	Integer bookTicket(Seat seatNew);
	void setSeat(Seat seatNew);
	Booking bookingDetails(String username);
	void deleteBooking(Booking booking);
	List<Seat> getDetails(String moviename);
	List<Booking> report(Booking booking) throws ParseException;
	Integer addDetails(Seat seat);
	String delete(Integer bookingid);

}
