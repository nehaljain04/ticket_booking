package com.service.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.service.model.ResponseMsg;
import com.service.model.User;
import com.service.service.UserManagementService;

@CrossOrigin
@RestController
@RequestMapping(value = "")
@ComponentScan("com.service.*")
public class UserAPI {

	@Autowired
	private UserManagementService userManagementService;

	@PostMapping(value = "/login")
	public ResponseEntity<User> validateUser(@RequestBody User user) throws Exception {
		try {
			System.out.println("api class " + user.getUsername());
			System.out.println("api class " + user.getPassword());
			User user1 = userManagementService.validateUser(user);

			System.out.println("hello api class");
			if (user1 != null) {
				 ResponseEntity<User> response= new ResponseEntity<User>(user1,HttpStatus.OK);
				System.out.println("if condition");
				return response;
			} else {
				 ResponseEntity<User> response= new ResponseEntity<User>(user1,HttpStatus.NOT_FOUND);
				System.out.println("else condition");
				return response;
			}

		} catch (Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		}
	}

	@PostMapping(value = "/signup")
	public ResponseEntity<ResponseMsg> registerUser(@RequestBody User user) throws Exception {
		try {

			String username;
			username = userManagementService.registerUser(user);
			System.out.println("username of api class is: " + username);
			String successMessage = "User added successfully";
			ResponseMsg responseMsg = new ResponseMsg();
			responseMsg.setResponseMessage(successMessage);
			ResponseEntity<ResponseMsg> response = new ResponseEntity<ResponseMsg>(responseMsg, HttpStatus.CREATED);
			return response;
			
		} catch (Exception e) {
			System.out.println(e);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		}
	}
}
