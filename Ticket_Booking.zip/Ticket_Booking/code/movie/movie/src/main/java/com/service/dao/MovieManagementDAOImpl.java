package com.service.dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.service.entity.MovieEntity;
import com.service.model.Movie;

@Repository(value = "movieManagementDAO")
public class MovieManagementDAOImpl implements MovieManagementDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Movie getMovieDetails(String moviename) {
		Movie movie = null;
		MovieEntity movieEntity = entityManager.find(MovieEntity.class, moviename);
		if (movieEntity != null) {
			movie = new Movie();
			movie.setMoviename(movieEntity.getMoviename());
			movie.setRatings(movieEntity.getRatings());
			movie.setGenre(movieEntity.getGenre());
		}
		return movie;
	}

	@Override
	public String addMovie(Movie movie) {
		MovieEntity movieEntity=new MovieEntity();
		movieEntity.setMoviename(movie.getMoviename());
		movieEntity.setRatings(movie.getRatings());
		movieEntity.setGenre(movie.getGenre());
		entityManager.persist(movieEntity);
		return movieEntity.getMoviename();
	}

	@Override
	public Void updateUser(String moviename, Integer ratings) {
		MovieEntity movieEntity=entityManager.find(MovieEntity.class,moviename);
		movieEntity.setRatings(ratings);
		return null;
	}

	@Override
	public void deleteMovie(String moviename) {
		MovieEntity movieEntity=entityManager.find(MovieEntity.class,moviename);
		entityManager.remove(movieEntity);
	}

	@Override
	public List<Movie> getAllMovie() {
		List<Movie> movieList=null;
		String queryString ="select d from MovieEntity d";
		Query query=entityManager.createQuery(queryString);
		List<MovieEntity> result = query.getResultList();
		
		movieList=new ArrayList<Movie>();
		
		for(MovieEntity movieEntity:result) {
			Movie movie=new Movie();
			movie.setMoviename(movieEntity.getMoviename());
			movie.setGenre(movieEntity.getGenre());
			movie.setRatings(movieEntity.getRatings());
			movieList.add(movie);
		}
		return movieList;
	}

}
