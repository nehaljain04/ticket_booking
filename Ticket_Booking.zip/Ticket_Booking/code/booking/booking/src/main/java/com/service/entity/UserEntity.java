package com.service.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="user")
public class UserEntity {
	@Id
	private String username;
	private String passwrd;
	private Long mobile;
	private String email;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="rolename")
	private RoleEntity rolename;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return passwrd;
	}
	public void setPassword(String passwrd) {
		this.passwrd = passwrd;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public RoleEntity getRole() {
		return rolename;
	}
	public void setRole(RoleEntity role) {
		this.rolename = role;
	}
		
}