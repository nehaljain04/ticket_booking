package com.service.model;
public class Seat {

	private Integer seatid;
	private String theatrename;
	private String moviename;
	private Integer remainingseats;
	private Integer rate;
	private String date;
	private String time;
	private Integer seatrequired;
	private String username;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Integer getSeatrequired() {
		return seatrequired;
	}
	public void setSeatrequired(Integer seatrequired) {
		this.seatrequired = seatrequired;
	}
	public Integer getSeatid() {
		return seatid;
	}
	public void setSeatid(Integer seatid) {
		this.seatid = seatid;
	}
	public String getTheatrename() {
		return theatrename;
	}
	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public Integer getRemainingseats() {
		return remainingseats;
	}
	public void setRemainingseats(Integer remainingseats) {
		this.remainingseats = remainingseats;
	}
	public Integer getRate() {
		return rate;
	}
	public void setRate(Integer rate) {
		this.rate = rate;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
}
